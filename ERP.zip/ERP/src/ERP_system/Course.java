package ERP_system;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseCode;
    private String title;
    private Professor professor;
    private int credits;
    private List<String> prerequisites;
    private String schedule;
    private String syllabus;
    private String officeHours;
    private int enrollmentLimit;
    private List<Student> studentList = new ArrayList<>();
    private LocalDate dropDeadline;
    private int currentEnrollment;


    private TeachingAssistant TA ;

    public Course(String courseCode, String title, Professor professor, int credits, List<String> prerequisites, String syllabus, int enrollmentLimit, String schedule, LocalDate dropDeadline) {
        this.courseCode = courseCode;
        this.title = title;
        this.credits = credits;
        this.prerequisites = prerequisites;
        this.syllabus = syllabus;
        this.professor = professor;
        this.enrollmentLimit = enrollmentLimit;
        this.schedule = schedule;
        this.currentEnrollment = 0;
        this.dropDeadline = dropDeadline;
    }

    public TeachingAssistant getTA() {
        return TA;
    }

    public void setTA(TeachingAssistant TA) {
        this.TA = TA;
    }
    public boolean isFull() {
        return currentEnrollment >= enrollmentLimit;
    }

    public int getCurrentEnrollment() {
        return currentEnrollment;
    }

    public void setCurrentEnrollment(int currentEnrollment) {
        this.currentEnrollment = currentEnrollment;
    }


    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseTitle() {
        return title;
    }


    public Professor getProfessor() {
        return professor;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setPrerequisites(List<String> prerequisites) {
        this.prerequisites = prerequisites;
    }

    public List<String> getPrerequisites() {
        return prerequisites;
    }

    public String getSyllabus() {
        return syllabus;
    }

    public void setSyllabus(String syllabus) {
        this.syllabus = syllabus;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public int getCredits() {
        return credits;
    }

    public String getOfficeHours() {
        return officeHours;
    }

    public void setOfficeHours(String officeHours) {
        this.officeHours = officeHours;
    }

    public int getEnrollmentLimit() {
        return enrollmentLimit;
    }

    public void setEnrollmentLimit(int enrollmentLimit) {
        this.enrollmentLimit = enrollmentLimit;
    }

    public void enrollStudent(Student student) {
        if (studentList.size() < enrollmentLimit) {
            studentList.add(student);
            currentEnrollment++;
        } else {
            System.out.println("Enrollment Limit Exceeded!!");
        }
    }

    public void deEnrollStudent(Student student) {
        studentList.remove(student);
        currentEnrollment--;
    }

    public void viewEnrolledStudents() {
        if (studentList.isEmpty()) {
            System.out.println("No students enrolled");
        } else {
            System.out.println("Enrolled Students:");
            for (Student student : studentList) {
                System.out.println("Student: " + student.getEmail() + ", Semester: " + student.getSemester());
            }
        }
    }

    public boolean isPresent(Student student) {
        return studentList.contains(student);
    }

    public LocalDate getDropDeadline() {
        return dropDeadline;
    }

    public void setDropDeadline(LocalDate dropDeadline) {
        this.dropDeadline = dropDeadline;
    }
}
