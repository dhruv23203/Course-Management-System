package ERP_system;

import java.util.Date;

public class AcademicComplaint implements Complaint {
    private String studentEmail;
    private String description;
    private String status;
    private Date date;

    // Constructor to initialize the fields
    public AcademicComplaint(String studentEmail, String description, Date date) {
        this.studentEmail = studentEmail;
        this.description = description;
        this.status = "Pending";  // Default status
        this.date = date;
    }

    @Override
    public String getStudentEmail() {
        return studentEmail;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Complaint by: " + studentEmail + ", Description: " + description + ", Status: " + status + ", Date: " + date;
    }
}
