package ERP_system;

public interface Complaint {
    String getStudentEmail();
    String getDescription();
    String getStatus();
    void setStatus(String status);
}
