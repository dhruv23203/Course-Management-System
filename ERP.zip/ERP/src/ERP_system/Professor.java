
package ERP_system;

import java.util.*;

public class Professor extends User {


    private boolean availablity;
    private Course course;
    private List<TeachingAssistant> TAList = new ArrayList<>();

    public Professor(String email, String password) {
        super(email, password);
        availablity = true;
    }

    public static Professor signUp(String email, String password) {
        return new Professor(email, password);
    }
    public boolean isAvailablity() {
        return availablity;
    }
    public void setAvailablity(boolean val){
        availablity = val;
    }

    @Override
    public void displayMenu() {
        System.out.println("Professor Menu:");
        System.out.println("1. Manage Courses");
        System.out.println("2. View Enrolled Students");
        System.out.println("3. Grade Students");
        System.out.println("4. View Course Details");
        System.out.println("5. View Grade of Enrolled Student ");
        System.out.println("6. View Feedbacks ");
        System.out.println("7. Assign TA to the course ");
    }
    public Course getProfCourse() {
        return course;
    }

    public void setProfCourse(Course course) {
        if(course == null){
            this.course = null;
            return;
        }
        this.course = course;
        System.out.println("Professor selected for " + course.getCourseTitle());
        this.setAvailablity(false);
    }

    public void ManageCoursesMenu(){
        System.out.println("Manage Courses : ");
        System.out.println("1. Update Syllabus  ");
        System.out.println("2. Update Class Timings  ");
        System.out.println("3. Update Credits  ");
        System.out.println("4. Update Course Prerequisites ");
        System.out.println("5. Update Enrollment Limits ");
        System.out.println("6. Update Office Hours ");
        System.out.println("Enter 0 to exit ");
    }

    public void viewStudents(){
        course.viewEnrolledStudents();
    }



    public void finalizeGrade(Student student) {
        TeachingAssistant ta = this.course.getTA();
        if (ta != null) {
            String suggestedGrade = ta.getGradeSuggestion(student);

            if (suggestedGrade != null) {
                System.out.println("TA suggested grade: " + suggestedGrade + " for student: " + student.getEmailId());
                student.setGrade(this.course, suggestedGrade);
                System.out.println("Professor finalized grade: " + suggestedGrade + " for student: " + student.getEmailId());
            } else {
                System.out.println("No grade suggestion available from the TA for student: " + student.getEmailId());
                Scanner scanner = new Scanner(System.in);
                System.out.print("Enter grade: ");
                String grade = scanner.nextLine();
                student.setGrade(this.course, grade);
                System.out.println("Grade added successfully");
                scanner.close();
            }
        } else {
            System.out.println("No TA assigned to the course. Please enter grade for student: " + student.getEmailId());
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter grade: ");
            String grade = scanner.nextLine();
            student.setGrade(this.course, grade);
            System.out.println("Grade added successfully");

        }
    }


    public void updateSyllabus(Course course ,String syllabus) {
        course.setSyllabus(syllabus);
    }

    public void updateSchedule(Course course ,String timings) {
        course.setSchedule(timings);
    }

    public void updateCredits(Course course ,int credits) {
        course.setCredits(credits);
    }

    public void updatePrerequisites(Course course , List<String> prerequisites) {
        course.setPrerequisites(prerequisites);
    }

    public void updateEnrollmentLimit(Course course ,int limit) {
        course.setEnrollmentLimit(limit);
    }

    public void updateOfficeHours(Course course ,String officeHour) {
        course.setOfficeHours(officeHour);
    }
    public void viewCourseDetails() {
        System.out.println("Course Title: " + course.getCourseTitle());
        System.out.println("Course Code: " + course.getCourseCode());
        System.out.println("Syllabus: " + course.getSyllabus());
        System.out.println("Schedule: " + course.getSchedule());
        System.out.println("Credits: " + course.getCredits());
        System.out.println("Prerequisites: " + course.getPrerequisites());
        System.out.println("Enrollment Limit: " + course.getEnrollmentLimit());
        System.out.println("Professor Office Hours: " + course.getOfficeHours());
    }

    public void viewFeedback(Feedback feedback){
        feedback.displayFeedback(getProfCourse().getCourseCode());
    }
    public void promoteToTA(Student student, Administrator admin, Course course) {

        if (!student.isCompletedCourse(course.getCourseCode())) {
            System.out.println("Student has not completed the course: " + course.getCourseTitle());
            return;
        }
        String grade = student.getGrades().get(course);

        if (grade != null && (grade.equals("A") || grade.equals("A+") || grade.equals("A-") || grade.equals("B+"))) {
            TeachingAssistant ta = new TeachingAssistant(student.getEmailId(), student.getPassword());
            ta.setCourse(course);
            course.setTA(ta);
            admin.getTARecords().put(student.getEmailId(), ta);

            System.out.println("Student with email: " + student.getEmailId() + " is promoted to TA for course: " + course.getCourseTitle());
        } else {
            System.out.println("Student does not qualify to be a TA for course: " + course.getCourseTitle());
        }
    }




}

