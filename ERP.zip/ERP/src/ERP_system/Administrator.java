package ERP_system;
import java.time.LocalDate;

import java.util.*;

public class Administrator extends User {

    private Map<Integer, Map<String, Course>> courseCatalog = new HashMap<>();
    private Map<String, Student> studentRecords = new HashMap<>();


    private Map<String, Professor> professorRecords = new HashMap<>();
    private Map<String, TeachingAssistant> TARecords = new HashMap<>();
    private Map<String , Complaint> complaints = new HashMap<>();


    public Administrator(String password) {
        super(password);
    }

    public Map<String, TeachingAssistant> getTARecords() {
        return TARecords;
    }
    public Map<String, Professor> getProfessorRecords() {
        return professorRecords;
    }

    public Map<String , Student> getStudentRecords(){
        return studentRecords;
    }

    public Map<String , Complaint> getComplaints() {
        return complaints;
    }
    @Override
    public void displayMenu() {
        System.out.println("Administrator Menu:");

        System.out.println("1. Manage Course Catalog");
        System.out.println("2. Manage Student Records");
        System.out.println("3. Assign Professors to Courses");
        System.out.println("4. Handle Complaints");

    }
    public void CourseCatalogMenu(){
        System.out.println("1. View Course Catalog ");
        System.out.println("2. Add Course in Course Catalog ");
        System.out.println("3. Drop Course from Course Catalog ");
        System.out.println("Enter 0 to exit ");
    }
    public void studentRecordsMenu(){
        System.out.println("1. View Student Records ");
        System.out.println("2. Update Student Records ");
        System.out.println("3. See Grade of a Student ");
        System.out.println("4. Update Grade of a Student");
        System.out.println("Enter 0 to exit ");
    }

    public void viewCourseCatalog(int semester) {

        System.out.println("Course Catalog for Semester " + semester + ":");
        Map<String, Course> semesterCourses = courseCatalog.get(semester);
        if (semesterCourses != null) {
            for (Course course : semesterCourses.values()) {
                System.out.println(course.getCourseCode() + "  " + course.getCourseTitle());
            }
        } else {
            System.out.println("No courses available for this semester.");
        }
    }


    public void addCourse(int semester, String courseCode, String title, Professor professor, int credits, List<String> prerequisites, String schedule, String syllabus, int enrollmentLimit, LocalDate dropDeadline) {
        Course newCourse = new Course(courseCode, title, professor, credits, prerequisites, syllabus, enrollmentLimit, schedule, dropDeadline);

        courseCatalog
                .computeIfAbsent(semester, k -> new HashMap<>())
                .put(courseCode, newCourse);

        System.out.println("Added new course: " + newCourse.getCourseTitle());

        professor.setProfCourse(newCourse);
    }

    public void deleteCourse(int semester, String courseCode) {
        Map<String, Course> semesterCourses = courseCatalog.get(semester);
        if (semesterCourses != null) {
            Course removed = semesterCourses.remove(courseCode);
            if (removed != null) {
                System.out.println("Course " + removed.getCourseTitle()+ " removed from catalog.");
                removed = null;
            } else {
                System.out.println("Course not found in catalog.");
            }
        }
    }


    public void viewStudentRecords() {
        System.out.println("Student Records:");
        for (Student student : studentRecords.values()) {
            if (student != null) {
                System.out.println(" Name : " + student.getName());
                System.out.println(" EmailID : " + student.getEmailId());
                System.out.println("Semester : " + student.getSemester());
                System.out.println("Address : " + student.getAddress());
                System.out.println();
            }
        }
    }

    public void updateStudentRecord(String Name ,String emailId, int newSemester , String address) {
        Student student = studentRecords.get(emailId);
        if (student != null) {
            student.setName(Name);
            student.setEmailId(emailId);
            student.setSemester(newSemester);
            student.setAddress(address);
            System.out.println("Record is Successfully updated");
        } else {
            System.out.println("Student not found.");
        }
    }
    public void updateGrade(Student student, String courseCode, String grade) {
            Course course = courseCatalog.get(student.getSemester()).get(courseCode);
            if (studentRecords.containsValue(student)){
                student.setGrade(course,grade);
                System.out.println("Grade Updated Successfully");
            }
            else{
                System.out.println("Student not Found ");
            }
    }


    public void handleComplaint(String studentEmail, Scanner scanner) {
        Complaint complaint = complaints.get(studentEmail);
        if (complaint != null && complaint.getStatus().equals("Pending")) {
            System.out.println("Enter Resolution method: (if not resolved then type NO) ");
            String resolution = scanner.nextLine();
            if (resolution.equalsIgnoreCase("NO")) {
                System.out.println("The complaint is not resolved yet.");
                return;
            }
            complaint.setStatus("Resolved with: " + resolution);
            System.out.println("Complaint from " + studentEmail + " resolved.");
        } else {
            System.out.println("No pending complaints found for student: " + studentEmail);
        }
    }



    public void addComplaint(String email, Complaint complaint) {
        complaints.put(email, complaint);
        System.out.println("Complaint added for student: " + email);
    }

    public Map<Integer, Map<String, Course>> getCourseCatalog() {
        return courseCatalog;
    }
}
