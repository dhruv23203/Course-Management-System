package ERP_system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class Feedback<T> {
    private Map<String, List<T>> feedbackList = new HashMap<>();

    public void addFeedback(String coursecode , T content) {
        feedbackList.putIfAbsent(coursecode, new ArrayList<>());
        feedbackList.get(coursecode).add(content);
    }

    public void displayFeedback(String coursecode) {
        List<T> feedbacks = feedbackList.get(coursecode);
        if (feedbacks != null) {
            for (T feedback : feedbacks) {
                System.out.println(feedback);
            }
        } else {
            System.out.println("No feedback available for this course.");
        }
    }

    public List<T> getFeedbackList(String coursecode) {
        return feedbackList.get(coursecode);
    }
}
