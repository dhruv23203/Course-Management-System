package ERP_system;

public class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}
