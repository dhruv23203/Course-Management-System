package ERP_system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Student extends User {
    private String password;
    private String name;
    private int semester;
    private int sem_credits;
    private String address;
    private String emailId;
    private Map<Integer, Map<String, Course>> registeredCourses;
    private Map<Integer, Map<String, Course>> completedCourses;
    private Map<Course, String> grades;
    private boolean isSemesterCompleted;

    public Student(String email, String password) {
        super(email, password);
        this.password = password;
        this.emailId = email;
        this.semester = 1;
        this.sem_credits = 0;
        this.isSemesterCompleted = false;
        registeredCourses = new HashMap<>();
        completedCourses = new HashMap<>();
        grades = new HashMap<>();
    }

    public static Student signup(String email, String password) {
        System.out.println("Student account created for: " + email);
        return new Student(email, password);
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void markSemesterCompleted() {
        if (sem_credits == 20 && registeredCourses.get(semester) != null && !registeredCourses.get(semester).isEmpty()) {
            for (Course course : registeredCourses.get(semester).values()) {
                String grade = grades.get(course);
                if (grade == null || grade.equals("F")) {
                    if (grade != null && grade.equals("F")) {
                        System.out.println("You cannot proceed to the next semester due to failing the course: " + course.getCourseTitle());
                    }
                    return;
                }
                course.deEnrollStudent(this);
            }
            isSemesterCompleted = true;
            completedCourses.put(semester, new HashMap<>(registeredCourses.get(semester)));
            registeredCourses.get(semester).clear();
            semester++;
            sem_credits = 0;
        }
    }

    public void viewAvailableCourses(Map<Integer, Map<String, Course>> courseCatalog, int sem) {
        System.out.println("Available Courses for Semester " + sem + " : ");
        Map<String, Course> sem_courses = courseCatalog.get(sem);
        if (sem_courses != null) {
            for (Course course : sem_courses.values()) {
                System.out.println(course.getCourseCode() + "  " + course.getCourseTitle());
            }
        } else {
            System.out.println("No courses available!");
        }
    }

    private boolean hasCompletedPrerequisites(Course course) {
        List<String> prerequisites = course.getPrerequisites();
        if (prerequisites == null || prerequisites.isEmpty()) {
            return true;
        }

        for (String prerequisite : prerequisites) {
            boolean prerequisiteCompleted = false;
            for (Map<String, Course> semesterCourses : completedCourses.values()) {
                if (semesterCourses.containsKey(prerequisite)) {
                    prerequisiteCompleted = true;
                    break;
                }
            }
            if (!prerequisiteCompleted) {
                return false;
            }
        }
        return true;
    }

    public void registerForCourses(Course courseName, int sem) {
        isSemesterCompleted = false;
        if (sem_credits + courseName.getCredits() <= 20) {
            if (registeredCourses.get(sem) != null && registeredCourses.get(sem).containsKey(courseName.getCourseCode())) {
                System.out.println("Already registered.");
                return;
            }

            if (hasCompletedPrerequisites(courseName)) {
                registeredCourses.computeIfAbsent(sem, k -> new HashMap<>()).put(courseName.getCourseCode(), courseName);
                sem_credits += courseName.getCredits();
                System.out.println("Registered for: " + courseName.getCourseCode() + "  " + courseName.getCourseTitle());
            } else {
                System.out.println("You have not completed the prerequisite course.");
            }
        } else {
            System.out.println("Credit limit exceeded.");
        }
    }

    public int getPoints(String grade) {
        switch (grade.toUpperCase()) {
            case "A": return 10;
            case "A-": return 9;
            case "B": return 8;
            case "B-": return 7;
            case "C": return 6;
            case "C-": return 5;
            case "D": return 4;
            case "F": return 0;
            default:
                System.out.println("Enter a valid grade.");
                return 0;
        }
    }

    public double sgpa(int inputSemester) {
        markSemesterCompleted();
        if (inputSemester > semester) {
            System.out.println("Cannot calculate SGPA for a future semester.");
            return 0;
        }
        if (inputSemester == semester && !isSemesterCompleted) {
            System.out.println("Current semester is not completed yet.");
            return 0;
        }

        Map<String, Course> sem_courses = completedCourses.get(inputSemester);
        int totalPoints = 0;
        int totalCredits = 0;

        if (sem_courses != null && !sem_courses.isEmpty()) {
            for (Course course : sem_courses.values()) {
                int courseCredits = course.getCredits();
                String grade = grades.get(course);
                totalPoints += getPoints(grade) * courseCredits;
                totalCredits += courseCredits;
            }
            return totalCredits == 0 ? 0 : (double) totalPoints / totalCredits;
        } else {
            System.out.println("No courses found for this semester or semester not completed.");
            return 0;
        }
    }

    public double cgpa() {
        double totalSgpa = 0;
        int completedSemesters = 0;
        markSemesterCompleted();

        for (int i = 1; i < semester; i++) {
            double semSgpa = sgpa(i);
            if (semSgpa > 0) {
                totalSgpa += semSgpa;
                completedSemesters++;
            }
        }

        return completedSemesters > 0 ? totalSgpa / completedSemesters : 0;
    }

    public void dropCourse(Course course) {
        Map<String, Course> semesterCourses = registeredCourses.get(semester);
        if (semesterCourses != null) {
            Course courseName = semesterCourses.remove(course.getCourseCode());
            if (courseName != null) {
                sem_credits -= course.getCredits();
                System.out.println("Dropped course: " + courseName.getCourseTitle());
                course.deEnrollStudent(this);
            } else {
                System.out.println("You are not registered for this course.");
            }
        }
    }

    public void viewSchedule() {
        System.out.println("Your registered courses for Semester " + semester + ":");
        Map<String, Course> semesterCourses = registeredCourses.get(semester);
        if (semesterCourses != null) {
            for (Course course : semesterCourses.values()) {
                System.out.println(course.getCourseCode() + ": " + course.getSchedule());
            }
        } else {
            System.out.println("You have no registered courses this semester.");
        }
    }

    public void viewGrades() {
        markSemesterCompleted();
        if (semester > 1) {
            for (int i = 1; i < semester; i++) {
                System.out.println("Grades for Semester " + i + " :");
                Map<String, Course> courseList = completedCourses.get(i);
                if (courseList != null) {
                    for (Course course : courseList.values()) {
                        System.out.println(course.getCourseTitle() + "  - " + grades.get(course));
                    }
                } else {
                    System.out.println("No grades available for Semester " + i);
                }
            }
        } else {
            System.out.println("No grades available");
        }
    }

    @Override
    public void displayMenu() {
        System.out.println("Student Menu:");
        System.out.println("1. View Available Courses");
        System.out.println("2. Register for Courses");
        System.out.println("3. View Schedule");
        System.out.println("4. Drop Courses");
        System.out.println("5. View Grades");
        System.out.println("6. Calculate SGPA");
        System.out.println("7. Calculate CGPA");
        System.out.println("8. Submit Complaint");
        System.out.println("9. View Complaints");
        System.out.println("10. Give Feedback ");
    }

    public Map<Course, String> getGrades() {
        return grades;
    }

    public void setGrade(Course course, String grade) {
        grades.put(course, grade);
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public boolean isCompletedCourse(String coursecode) {
        if (semester == 1) {
            return false;
        }
        return completedCourses.get(semester - 1) != null && completedCourses.get(semester - 1).containsKey(coursecode);
    }
}
