package ERP_system;

public class DropDeadlinePassedException extends Exception {
    public DropDeadlinePassedException(String message) {
        super(message);
    }
}
