package ERP_system;
import java.util.*;
import java.time.LocalDate;

public class Main {
    private static Administrator admin = new Administrator("adminPassword");
    static Feedback<Object> feedback = new Feedback<>();

    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        initializeData();

        System.out.println("Welcome to the ERP Portal");

        while (true) {
            System.out.println("\n1. Login");
            System.out.println("2. Signup");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    loginUser(scanner);
                    break;
                case 2:
                    signupUser(scanner);
                    break;
                case 3:
                    System.out.println("Exiting Portal...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Enter a valid choice and try again!");
            }
        }
    }

    private static void initializeData() {
        // Professors
        Student student = new Student ("A" , "123");
        Student student1 = new Student ("B" , "123");
        Student student2 = new Student ("C" , "123");
        Student student3 = new Student ("D" , "123");
        admin.getStudentRecords().put("A" ,student );
        admin.getStudentRecords().put("B" ,student1 );
        admin.getStudentRecords().put("C" ,student2 );
        admin.getStudentRecords().put("D" ,student3 );
        Professor profA = new Professor("A", "123");
        Professor profB = new Professor("B", "123");
        Professor profC = new Professor("C", "123");
        Professor profD= new Professor("D", "123");
        Professor profE = new Professor("E", "123");
        Professor profF = new Professor("F", "123");
        admin.getProfessorRecords().put("A",profA);
        admin.getProfessorRecords().put("B",profB);
        admin.getProfessorRecords().put("C",profC);
        admin.getProfessorRecords().put("D",profD);
        admin.getProfessorRecords().put("E",profE);
        admin.getProfessorRecords().put("F",profF);

        // Courses
        List<String> prerequisitesCS102 = new ArrayList<>();
        prerequisitesCS102.add("CS101");


        LocalDate dropDeadline1 = LocalDate.now().minusDays(1);
        LocalDate dropDeadline2 = LocalDate.now().plusWeeks(2);
        LocalDate dropDeadline3 = LocalDate.now().plusWeeks(2);
        LocalDate dropDeadline4 = LocalDate.now().plusWeeks(2);
        LocalDate dropDeadline5 = LocalDate.now().plusWeeks(2);
        LocalDate dropDeadline6 = LocalDate.now().plusWeeks(2);

        admin.addCourse(1, "CSE101", "Introduction To Programming", profA, 4, new ArrayList<>(), "Tue-Thu 1-3 PM", "Basic Programming", 50, dropDeadline1);
        admin.addCourse(2, "CSE102", "Data Structures", profF, 4, prerequisitesCS102, "Tue-Thu 1-3 PM", "Intermediate Programming", 50, dropDeadline2);
        admin.addCourse(1, "MTH101", "Linear Algebra", profB, 4, new ArrayList<>(), "Mon-Wed 2-4 PM", "Matrices And Determinants", 50, dropDeadline3);
        admin.addCourse(1, "ECE101", "Digital Circuits", profC, 4, new ArrayList<>(), "Mon-Wed 9-11 AM", "Basic Physics", 50, dropDeadline4);
        admin.addCourse(1, "DES101", "Introduction to HCI", profD, 4, new ArrayList<>(), "Tue-Thu 2-4 PM", "Basic Design", 50, dropDeadline5);
        admin.addCourse(1, "ENG101", "Communication Skills", profE, 4, new ArrayList<>(), "Mon-Wed 3-5 PM", "Basic Writing Skills and Communication Skills", 50, dropDeadline6);


    }




    public static void signupUser(Scanner scanner) {
        System.out.println("Signup as:\n1. Student\n2. Professor");
        int userType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        switch (userType) {
            case 1:
                Student dummyStudent = admin.getStudentRecords().get(email);
                if (dummyStudent == null) {
                    Student newStudent = Student.signup(email, password);
                    admin.getStudentRecords().put(email, newStudent);

                } else {
                    System.out.println("Already signed up.");
                }
                break;

            case 2:
                Professor dummyProfessor = admin.getProfessorRecords().get(email);
                if (dummyProfessor == null) {
                    Professor newProfessor = Professor.signUp(email, password);
                    newProfessor.setAvailablity(true);
                    admin.getProfessorRecords().put(email, newProfessor);
                    System.out.println("Professor account created successfully.");
                } else {
                    System.out.println("Already signed up.");
                }
                break;

            default:
                System.out.println("Invalid user type.");
        }
    }

    public static void loginUser(Scanner scanner) {
        System.out.println("Login as:\n1. Student\n2. Professor\n3. Admin\n4. Teaching Assistant");
        int userType = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            switch (userType) {
                case 1:
                    System.out.print("Enter Email: ");
                    String studentEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String studentPassword = scanner.nextLine();

                    Student student = admin.getStudentRecords().get(studentEmail);
                    if (student == null || !student.login(studentEmail, studentPassword)) {
                        throw new InvalidLoginException("Invalid student login.");
                    }
                    handleStudentMenu(student, scanner);
                    break;

                case 2:
                    System.out.print("Enter Email: ");
                    String profEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String profPassword = scanner.nextLine();

                    Professor professor = admin.getProfessorRecords().get(profEmail);
                    if (professor == null || !professor.login(profEmail, profPassword)) {
                        throw new InvalidLoginException("Invalid professor login.");
                    }
                    handleProfessorMenu(professor, scanner);
                    break;

                case 3:
                    System.out.print("Enter Admin Password: ");
                    String adminPassword = scanner.nextLine();

                    if (!admin.login(adminPassword)) {
                        throw new InvalidLoginException("Invalid admin login.");
                    }
                    handleAdminMenu(scanner);
                    break;

                case 4:
                    System.out.print("Enter Email: ");
                    String TAEmail = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String TAPassword = scanner.nextLine();
                    TeachingAssistant TA = admin.getTARecords().get(TAEmail);
                    if (TA == null || !TA.login(TAEmail, TAPassword)) {
                        throw new InvalidLoginException("Invalid TA login.");
                    }
                    handleTAMenu(TA);
                    break;

                default:
                    System.out.println("Invalid user type!");
            }
        } catch (InvalidLoginException e) {
            System.out.println(e.getMessage());
        }
    }


    // Handle student menu
    private static void handleStudentMenu(Student student, Scanner scanner) {
        while (true) {
            student.displayMenu();
            System.out.println("Enter your choice (or 0 to exit):");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 0) {
                System.out.println("Exiting student menu...");
                break;
            }

            switch (choice) {
                case 1:
                    student.viewAvailableCourses(admin.getCourseCatalog(), student.getSemester());
                    break;
                case 2:
                    System.out.print("Enter course code to register: ");
                    String courseCode = scanner.nextLine();
                    Course courseToRegister = admin.getCourseCatalog().get(student.getSemester()).get(courseCode);
                    if (courseToRegister != null) {
                        try {
                            if (courseToRegister.isFull()) {
                                throw new CourseFullException("Course " + courseToRegister.getCourseTitle() + " is full. Registration failed.");
                            }
                            student.registerForCourses(courseToRegister, student.getSemester());
                            courseToRegister.enrollStudent(student);
                        } catch (CourseFullException e) {
                            System.out.println(e.getMessage());
                        }
                    } else {
                        System.out.println("Invalid course code.");
                    }
                    break;
                case 3:
                    student.viewSchedule();
                    break;
                case 4:
                    System.out.print("Enter course code to drop: ");
                    String dropCourseCode = scanner.nextLine();
                    Course courseToDrop = admin.getCourseCatalog().get(student.getSemester()).get(dropCourseCode);
                    if (courseToDrop != null) {
                        LocalDate today = LocalDate.now();
                        try {
                            if (today.isAfter(courseToDrop.getDropDeadline())) {
                                throw new DropDeadlinePassedException("Cannot drop course. The drop deadline has passed.");
                            } else {
                                student.dropCourse(courseToDrop);
                                courseToDrop.deEnrollStudent(student);
                                System.out.println("Course dropped successfully.");
                            }
                        }
                        catch(DropDeadlinePassedException e){
                            System.out.println(e.getMessage());
                        }
                    } else {
                        System.out.println("Invalid course code.");
                    }
                    break;
                case 5:
                    student.viewGrades();
                    break;
                case 6:
                    System.out.println("Enter the semester for which you want the SGPA");
                    int sem = scanner.nextInt();
                    scanner.nextLine();
                    double sgpa = student.sgpa(sem);
                    System.out.println("Your SGPA for semester " + sem + " is : " + sgpa);
                    break;
                case 7:
                    double cgpa = student.cgpa();
                    System.out.println("Your CGPA is: " + cgpa);
                    break;
                case 8:
                    System.out.print("Enter complaint description: ");
                    String complaintText = scanner.nextLine();
                    Complaint complaint = new AcademicComplaint(student.getEmailId(), complaintText, new java.util.Date());
                    admin.addComplaint(student.getEmailId(), complaint);
                    System.out.println("Complaint submitted: " + complaintText);
                    break;
                case 9:
                    for (Complaint complaint1 : admin.getComplaints().values()) {
                        if (complaint1.getStudentEmail().equals(student.getEmailId())) {
                            System.out.println(complaint1);
                        }
                    }
                    break;
                case 10:
                    System.out.println("Enter the Course code:");
                    String feedbackCourseCode = scanner.nextLine();

                    if (!student.isCompletedCourse(feedbackCourseCode)) {
                        System.out.println("You have not completed this course.");
                        break;
                    }

                    System.out.println("Enter 1 for Text Feedback");
                    System.out.println("Enter 2 for Numeric Feedback");
                    int num = scanner.nextInt();
                    scanner.nextLine();

                    switch (num) {
                        case 1:
                            System.out.println("Enter Text:");
                            String textFeedback = scanner.nextLine();
                            feedback.addFeedback(feedbackCourseCode, textFeedback);
                            System.out.println("Text feedback added for course: " + feedbackCourseCode);
                            break;

                        case 2:
                            System.out.println("Enter Rating (1-5):");
                            int rating = scanner.nextInt();
                            feedback.addFeedback(feedbackCourseCode, rating);
                            System.out.println("Numeric feedback added for course: " + feedbackCourseCode);
                            break;

                        default:
                            System.out.println("Invalid input.");
                            break;
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }


    // Handle professor menu
    private static void handleProfessorMenu(Professor professor, Scanner scanner) {
        while (true) {
            professor.displayMenu();
            System.out.println("Enter your choice (or 0 to exit):");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 0) {
                System.out.println("Exiting professor menu...");
                break;
            }

            switch (choice) {

                case 1:
                    professor.ManageCoursesMenu();
                    int ch = scanner.nextInt();
                    scanner.nextLine();
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }

                    switch(ch){
                        case 0: break;
                        case 1 :
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }
                            System.out.println("Enter Updated Syllabus : ");
                            String syllabus = scanner.nextLine();
                            professor.updateSyllabus(professor.getProfCourse(),syllabus);
                            System.out.println("Syllabus updated successfully : ");
                            break;

                        case 2:
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }
                            System.out.println("Enter Updated Class Timings : ");
                            String Timings = scanner.nextLine();
                            professor.updateSchedule(professor.getProfCourse(),Timings);
                            System.out.println(" Class Timings updated successfully  : ");
                            break;

                        case 3:
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }
                            System.out.println("Enter Updated Credits for the Course  : ");
                            int credits = scanner.nextInt();
                            scanner.nextLine();
                            professor.updateCredits(professor.getProfCourse(),credits);
                            System.out.println(" Credits Updated for the Course Successfully : ");
                            break;

                        case 4:
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }
                            System.out.println("Enter Prerequisites for the Course (comma-separated):");
                            String prerequisiteInput = scanner.nextLine();
                            List<String> prerequisites = Arrays.asList(prerequisiteInput.split("\\s*,\\s*")); // Split by commas and trim spaces

                            professor.updatePrerequisites(professor.getProfCourse(),prerequisites);
                            System.out.println(" Prerequisites  Updated Successfully ");


                        case 5:
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }
                            System.out.println("Enter Updated Enrollment Limits for the Course  : ");
                            int enrollmentLimit = scanner.nextInt();
                            scanner.nextLine();
                            professor.updateEnrollmentLimit(professor.getProfCourse(),enrollmentLimit);
                            System.out.println(" Enrollment Limits Updated Successfully  : ");
                            break;

                        case 6:
                            if(professor.getProfCourse() == null){
                                System.out.println("Professor do not have any course assigned yet ");
                                break;
                            }

                            System.out.println("Enter Updated Office Hours for the Course  : ");
                            String officeHours = scanner.nextLine();
                            professor.updateOfficeHours(professor.getProfCourse(), officeHours);
                            System.out.println(" Office Hours Updated Successfully  : ");
                            break;
                    }
                    break;
                case 2:
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    professor.viewStudents();
                    break;
                case 3:
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    System.out.print("Enter student email: ");
                    String studentEmail = scanner.nextLine();

                    Student studentToGrade = admin.getStudentRecords().get(studentEmail);
                    if (studentToGrade != null && professor.getProfCourse().isPresent(studentToGrade)) {
                        professor.finalizeGrade(studentToGrade);
                    } else {
                        System.out.println("Invalid student email.");
                    }
                    break;
                case 4 :
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    professor.viewCourseDetails();
                    break;
                case 5 :
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    System.out.println("Enter Student EmailID :");
                    String emailID = scanner.nextLine();
                    Student student = admin.getStudentRecords().get(emailID);
                    if(!professor.getProfCourse().isPresent(student)){
                        System.out.println("Student not registered in this course ");
                        break;
                    }
                    if(student != null){
                        student.viewGrades();
                    }
                    else{
                        System.out.println("Student not found ");
                    }
                    break;

                case 6:
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    professor.viewFeedback(feedback);
                    break;
                case 7:
                    if(professor.getProfCourse() == null){
                        System.out.println("Professor do not have any course assigned yet ");
                        break;
                    }
                    System.out.print("Enter student email: ");
                    String studEmail = scanner.nextLine();
                    Student TA = admin.getStudentRecords().get(studEmail);
                    if (TA != null) {
                        professor.promoteToTA(TA,admin,professor.getProfCourse());
                    } else {
                        System.out.println("Invalid student email.");
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // Handle administrator menu
    private static void handleAdminMenu(Scanner scanner) {
        while (true) {
            admin.displayMenu();
            System.out.println("Enter your choice (or 0 to exit):");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 0) {
                System.out.println("Exiting administrator menu...");
                break;
            }

            switch (choice) {
                case 1:
                     admin.CourseCatalogMenu();
                     int ch = scanner.nextInt();
                     scanner.nextLine();

                     switch(ch){
                         case 0: break;

                         case 1 :
                             System.out.print("Enter semester: ");
                             int semester = scanner.nextInt();
                             scanner.nextLine();
                             if(semester > 8){
                                 System.out.println("Invalid Semester No.");
                                 break;
                             }
                             admin.viewCourseCatalog(semester);
                             break;

                         case 2 :
                             System.out.print("Enter semester: ");
                             int sem = scanner.nextInt();
                             scanner.nextLine();
                             if(sem > 8){
                                 System.out.println("Invalid Semester No.");
                                 break;
                             }
                             System.out.print("Enter course code: ");
                             String courseCode = scanner.nextLine();
                             System.out.print("Enter course name: ");
                             String courseName = scanner.nextLine();
                             System.out.print("Enter professor email: ");
                             String profEmail = scanner.nextLine();
                             Professor professor = admin.getProfessorRecords().get(profEmail);
                             if (professor == null) {
                                 System.out.println("Professor not found.");
                                 break;
                             }
                             if(!professor.isAvailablity()){
                                 System.out.println("Professor Not Available ");
                                 break;
                             }

                             System.out.print("Enter credits: ");
                             int credits = scanner.nextInt();
                             scanner.nextLine();
                             System.out.print("Enter schedule: ");
                             String schedule = scanner.nextLine();
                             System.out.print("Enter syllabus: ");
                             String syllabus = scanner.nextLine();
                             System.out.print("Enter Enrollment Limit : ");
                             int limit = scanner.nextInt();
                             scanner.nextLine();
                             List<String> prerequisites = new ArrayList<>();
                             LocalDate dropDeadline = LocalDate.now().plusWeeks(2);
                             admin.addCourse(sem, courseCode, courseName, professor, credits, prerequisites, schedule, syllabus, limit, dropDeadline);

                             System.out.println("Course Added Successfully ");
                             break;

                         case 3 :
                            System.out.println("Enter semester:");
                            int sem1 = scanner.nextInt();
                            scanner.nextLine();
                             if(sem1 > 8){
                                 System.out.println("Invalid Semester No.");
                                 break;
                             }
                            System.out.println("Enter course code:");
                            String courseToDelete = scanner.nextLine();
                            admin.deleteCourse(sem1, courseToDelete);

                            System.out.println("Course deleted successfully.");
                            break;
                        default:
                            System.out.println("Invalid choice.");
                     }
                     break;

                case 2:
                      admin.studentRecordsMenu();
                      int ch1 = scanner.nextInt();
                      scanner.nextLine();

                      switch(ch1){
                          case 0: break;

                          case 1:
                              admin.viewStudentRecords();
                              break;

                          case 2:
                              System.out.println("Enter Name : ");
                              String name = scanner.nextLine();
                              System.out.println("Enter EmailID : ");
                              String email = scanner.nextLine();;
                              System.out.println("Enter Semester : ");
                              int sem_ = scanner.nextInt();
                              scanner.nextLine();
                              if(sem_ > 8){
                                  System.out.println("Invalid Semester No.");
                                  break;
                              }
                              System.out.println("Enter Address : ");
                              String address = scanner.nextLine();

                              admin.updateStudentRecord(name,email,sem_,address);
                              break;

                          case 3:
                              System.out.println("Enter Student EmailID :");
                              String emailID = scanner.nextLine();
                              Student student = admin.getStudentRecords().get(emailID);
                              if(student != null){
                                  student.viewGrades();
                              }
                              else{
                                  System.out.println("Student not found ");
                              }
                              break;

                          case 4 :
                              System.out.println("Enter Student EmailID :");
                              String emailId = scanner.nextLine();
                              scanner.nextLine();
                              System.out.println("Enter Course Code : ");
                              String coursecode = scanner.nextLine();
                              System.out.println("Enter Grade :");
                              String grade = scanner.nextLine();
                              Student dummystudent = admin.getStudentRecords().get(emailId);
                              if(dummystudent != null){
                                  Course dummyCourse = admin.getCourseCatalog().get(dummystudent.getSemester()).get(coursecode);
                                  if(dummyCourse != null && dummyCourse.isPresent(dummystudent)){
                                      admin.updateGrade(dummystudent,coursecode,grade);
                                  } else{
                                      System.out.println("Enter valid Course code or Student is not enrolled in the course ");
                                  }
                              }
                              else{
                                  System.out.println("Student not found ");
                              }
                              break;
                          default :
                              System.out.println("Invalid choice . Try Again !!!");

                      }
                      break;


                case 3:
                    System.out.println("Enter Semester : ");
                    int sem_var = scanner.nextInt();
                    scanner.nextLine();
                    if(sem_var > 8){
                        System.out.println("Invalid Semester No.");
                        break;
                    }
                    System.out.println("Enter Course code : ");
                    String code_no = scanner.nextLine();
                    System.out.println("Enter Professor EmailId");
                    String profEmail = scanner.nextLine();
                    Professor prof = admin.getProfessorRecords().get(profEmail);
                    if(prof != null && prof.isAvailablity()){
                        Course course = admin.getCourseCatalog().get(sem_var).get(code_no);
                        if(course != null ){
                            Professor oldProf = course.getProfessor();
                            if(oldProf != null){
                                oldProf.setProfCourse(null);
                                oldProf.setAvailablity(true);

                            }
                            prof.setProfCourse(course);
                        }
                        else{
                            System.out.println("Invalid Course code");

                        }
                    }
                    else{
                        System.out.println("Professor not available ");
                    }
                    break;
                case 4:
                    System.out.println("Enter Student Email Id :");
                    String email = scanner.nextLine();
                    Complaint complaint = admin.getComplaints().get(email);


                    admin.handleComplaint(email , scanner);
                    break;


                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    public static void handleTAMenu(TeachingAssistant ta) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            ta.displayMenu();
            System.out.println("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter the student's email to view their grades:");
                    String email = scanner.nextLine();
                    Student student = admin.getStudentRecords().get(email);;
                    if (student != null) {
                        ta.viewStudentGrades(student);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 2:
                    System.out.println("Enter the student's email to assist in grading:");
                    email = scanner.nextLine();
                    student = admin.getStudentRecords().get(email);
                    if (student != null) {
                        System.out.println("Enter the grade to assign:");
                        String grade = scanner.nextLine();
                        ta.suggestGrade(student, grade);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 3:
                    ta.displayStudents();
                    break;

                case 0:
                    System.out.println("Exiting TA menu...");
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

}


