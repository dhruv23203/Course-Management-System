package ERP_system;

import java.util.HashMap;
import java.util.Map;

public class TeachingAssistant extends Student {

    private Course course;
    private Map<Student, String> gradeSuggestions = new HashMap<>();  // Store grade suggestions for students

    public TeachingAssistant(String email, String password) {
        super(email, password);
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public void displayStudents() {
        course.viewEnrolledStudents();
    }

    public void viewStudentGrades(Student student) {
        Map<Course, String> grade = student.getGrades();
        if (grade != null) {
            String courseGrade = grade.get(this.course);
            if (courseGrade == null) {
                System.out.println("Student have not completed this course.");
            } else {
                System.out.println("Grades for Course: " + this.course.getCourseTitle() + " : " + courseGrade);
            }
        } else {
            System.out.println("Student has not completed this course.");
        }
    }

    // TA suggests a grade, which will later be finalized by the professor
    public void suggestGrade(Student student, String grade) {
        if(course.isPresent(student)){
        gradeSuggestions.put(student, grade);
        System.out.println("Suggested grade " + grade + " for student " + student.getEmailId() + " in course " + this.course.getCourseTitle());
        }
        else{
            System.out.println("Student has not completed this course.");
        }
    }

    // Method for the professor to retrieve the TA's grade suggestion for a student
    public String getGradeSuggestion(Student student) {
        return gradeSuggestions.get(student);
    }

    @Override
    public void displayMenu() {
        System.out.println("1. View Student Grades");
        System.out.println("2. Suggest Grades for Students");
        System.out.println("3. View Students Enrolled in the Course");
    }
}
