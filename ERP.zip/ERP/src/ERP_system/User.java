package ERP_system;

public abstract class User {

    private String email;
    private String password;

    public User(String email, String password){
        this.email = email;
        this.password = password;
    }
    public User(String password){
        this.password = password;
    }

    public String getEmail(){
        return email;
    }
    public boolean login(String password){
        return this.password.equals(password);
    }
    public boolean login(String email,String password){
        return this.email.equals(email) && this.password.equals(password);
    }
    public abstract void displayMenu();

}




